<?php	/*	CREATE TABLE users_vac	(	id int NOT NULL AUTO_INCREMENT,	userid int NOT NULL,	username varchar(255),	name varchar(255) NOT NULL,	country int NOT NULL,	city int NOT NULL,	spec varchar(255) NOT NULL,	act varchar(255) NOT NULL,	qual int NOT NULL,	info varchar(255) NOT NULL,	state int NOT NULL,	date datetime NOT NULL,	has_photo int NOT NULL, 	msg varchar(250) NOT NULL, 	PRIMARY KEY (id)	)		ALTER TABLE `users_vac` CONVERT TO CHARACTER SET utf8 COLLATE utf8_general_ci	*/		
	include "../adeon.php";
	include "../../wp-load.php";
	$db="users_vac";	
	$userid = get_current_user_id();	
	$username = $current_user->user_login;	
	if(!$userid) die(json_encode(array("error" => "Unauthorized access"), JSON_UNESCAPED_UNICODE));		
	if($_SERVER['REQUEST_METHOD'] === 'POST') {	
		$result = $wpdb->get_results("SELECT MAX(id) as max FROM $db");	
		if(!empty($wpdb->last_error)) die(json_encode(array("error" => $wpdb->last_error, "post"=> $_POST), JSON_UNESCAPED_UNICODE));		
		$max = $result[0]->max;	
		if($max === null) $max = 1; //Серёжа понял проблему !!!!!!!
		else $max++;				
		if(!$_FILES['vac-photo']['error']) {		
			$name = $_FILES['vac-photo']['name'];	
				if(!check_file_uploaded_name($name) || !check_file_uploaded_length($name)) {
					die(json_encode(array("error" => "Wrong file name"), JSON_UNESCAPED_UNICODE));			
				}

				if($_FILES['vac-photo']['size'] > 500000) {
					die(json_encode(array("error" => "Wrong file size"), JSON_UNESCAPED_UNICODE));			
				}			

				if (!file_exists("../../vac_data/users/$username")) {				
					mkdir("../../vac_data/users/$username", 0777, true);			
				}	

				move_uploaded_file($_FILES['vac-photo']['tmp_name'], "../../vac_data/users/$username/$max.jpg");		
		}		

		$data = array(
			'userid' => $userid,			
			'username' => $username,			
			'name' => $_POST['vac-name'],			
			'country' => $_POST['vac-country'],			
			'city' => $_POST['vac-city'],			
			'spec' => $_POST['vac-spec'],			
			'act' => $_POST['vac-act'],			
			'qual' => $_POST['vac-qual'],			
			'info' => $_POST['vac-info'],			
			'state' => 1,			
			'date' => current_time('mysql'),			
			'has_photo' => file_exists("../../vac_data/users/$username/$max.jpg")		
		);		
		$data_pattern = array('%d', '%s', '%s', '%d', '%d', '%s', '%s', '%d', '%s', '%d', '%s', '%d');				

		$wpdb->insert( $db, $data, $data_pattern);		
		if(!empty($wpdb->last_error)) die(json_encode(array("error" => $wpdb->last_error), JSON_UNESCAPED_UNICODE));		
		die(json_encode(array("action" => "insert"), JSON_UNESCAPED_UNICODE));	
	}
?>