<?php
	include "../../wp-load.php";

	$accept = isset($_POST['accept']) ? true : false;
	
	if($accept){
		$state=2;
		$txt = "Здравствуйте, ".$_POST['fio'].". Ваша заявка CV была одобрена. :\n ".$_POST['comment']."\n https://urbanconsulting.md/ru/job/cv/";
	} else {
		$state=0;
		$txt = "Здравствуйте, ".$_POST['fio'].". Ваша заявка CV была отклонена. \n ".$_POST['comment']."\n https://urbanconsulting.md/ru/job/cv/";
	}
		$result = $wpdb->update("users_cv", array(
			'state' => $state,
			'msg' => strlen($_POST["comment"]) ? $_POST["comment"] : "CV заполнено неправильно.",
			'time' => current_time('mysql')
			),
			array( 'id' => $_POST["cvid"]),
			array( '%d', '%s', '%s'),
			array( '%d' )
	);

	$to = $_POST['email'];
	$subject = "Рассмотрение заявки CV";
	$headers = "From: office@urbanconsulting.md" . "\r\n" .
	"CC: office@urbanconsulting.md";

	mail($to,$subject,$txt,$headers);
	header('Location: https://urbanconsulting.md/wp-admin/admin.php?page=mt-top-level-handle');
?>