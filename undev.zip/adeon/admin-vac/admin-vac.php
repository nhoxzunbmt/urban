<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<link rel="stylesheet" href="/adeon/admin-vac/admin-vac.css">
	</head>

	<body>
	<?php
		include get_home_path().'adeon/adeon.php';
		echo '<h2>Доступные Вакансии, ожидающие подтверждения</h2>';
	
		global $wpdb;
		$db="users_vac";
		$result = $wpdb->get_results("SELECT * FROM $db WHERE state=1", ARRAY_A);
		if(!empty($wpdb->last_error)) die($wpdb->last_error);
		
		if(!$result) {
			die("<p>Нет данных</p>");
		}

		foreach($result as $vac) { ?>
			<div class="cv-view">
				<div class="col-9">
					<div class="cv-view-field"><p><strong>ID</strong>: <?php echo $vac['id']; ?></p></div>
					<div class="cv-view-field"><p><strong>Пользователь</strong>: <?php echo $vac['username']; ?></p></div>
					<div class="cv-view-field"><p><strong>Страна</strong>: <?php echo $country[$vac['country']]; ?></p></div>
					<div class="cv-view-field"><p><strong>Город</strong>: <?php echo $city[$vac['country']][$vac['city']]; ?></p></div>
					<div class="cv-view-field"><p><strong>Специальность</strong>: <?php echo $vac['spec']; ?></p></div>
					<div class="cv-view-field"><p><strong>Сфера деятельности</strong>: <?php echo $vac['act']; ?></p></div>
					<div class="cv-view-field"><p><strong>Квалифицированный</strong>: <?php echo $vac['qual']; ?></p></div>
					<div class="cv-view-field"><p><strong>Информация</strong>: <?php echo $vac['info']; ?></p></div>
					<div class="cv-view-field"><p><strong>Дата</strong>: <?php echo $vac['date']; ?></p></div>
				</div>
			
				<div class="col-3 cv-view-photo"> 
					<?php 
						if($vac['has_photo']) echo '<div class="wrapper" style="background-image: url(/vac_data/users/'.$vac['username'].'/'.$vac['id'].'.jpg);"></div>';
						else  echo '<div class="wrapper" style="background-image: url(/wp-content/uploads/2017/03/camera.png);"></div>';
					?>
				</div>
				
				<div class="comment">
					<form action="/adeon/admin-vac/process.php" method="POST">
						<textarea name="comment" id="" cols="135" placeholder="Комментарий по поводу Вакансии..." rows="3"></textarea>
						<input type="hidden" name="vac-id" value="<?php echo $vac['id']; ?>">
						<div class="cv-view-buttons">
						<div class="btn-agree"><input type="submit" value="Принять" name='accept'></div>
						<div class="btn-disagree"><input type="submit" value="Отклонить" name='reject'></div>
						</div>
					</form>
				</div>
				
			</div>
		<? }
		
	?>
	</body>
</html>