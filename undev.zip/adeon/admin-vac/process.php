<?php
	include "../../wp-load.php";

	$accept = isset($_POST['accept']) ? true : false;
	
	if($accept){
		$state=2;
	} else {
		$state=0;
	}
	
	$wpdb->update("users_vac", array(
		'state' => $state,
		'msg' => strlen($_POST["comment"]) ? $_POST["comment"] : "Заявка заполнена неправильно.",
		'date' => current_time('mysql')
		),
		array( 'id' => $_POST["vac-id"]),
		array( '%d', '%s', '%s'),
		array( '%d' )
	);

	header('Location: https://urbanconsulting.md/wp-admin/admin.php?page=sub-page');
?>