$(document).ready(function() {
	$ = jQuery;

	$.ajax({
		type: "GET",
		url: "/adeon/cv/cv.php",
		async: true,
		cache: false,
		contentType: false,
		processData: false,
		success: function(data) {
			var obj = JSON.parse(data);
			if(obj.error === undefined) {
				if(obj.data === null) {
					$(".photo-profile img").attr("src", stockPhotoUrl);
					populateCountries("cv-country", "cv-city");
				}
				else {
					if(obj.has_photo) {
						$(".photo-profile img").attr("src","https://urbanconsulting.md/cv_data/users/"+obj.user_name+"/photo.jpg?"+(new Date()).getTime());
					}
					else {
						$(".photo-profile img").attr("src", stockPhotoUrl);
					}
					
					$("#cv-form input[name='cv-name']").val(obj.name);
					$("#cv-form input[name='cv-spec']").val(obj.spec);
					$("#cv-form textarea[name='cv-info']").html(obj.info);
					$("#cv-form input[name='cv-age']").val(obj.age);
					$("#cv-form input[name='cv-address']").val(obj.address);
					$("#cv-form input[name='cv-email']").val(obj.email);
					$("#cv-form input[name='cv-phone']").val(obj.phone);
					
					if(obj.state == 0) {
						$("#cv-status2").css("display", "block");
						$("#cv-status2").append(" Причина: "+obj.msg);
					}
					else if(obj.state == 1){
						$("#cv-status1").css("display", "block");
					}
					else {
						$("#cv-status3").css("display", "block");
					}
					
					indexToPopulate("cv-country", "cv-city", obj.country, obj.city);
				}
				
				toggleForm("#cv-form", true);
				console.log(obj);
			}
			else {
				alert("Ошибка: "+obj.error);
				console.log(obj);
			}
		},
		error: function(error) {
			alert("Ошибка при получении данных. "+error.status+": "+error.statusText);
		}
	});
});

$('#cv-photo').change(function() {
	var reader = new FileReader();
	reader.onload = function (e) {
		$('.photo-profile img').attr('src', e.target.result);
    }
    reader.readAsDataURL(this.files[0]);
});

$("#cv-form").submit(function(e) {
	e.preventDefault();
	
	if(!validateEmail($("#cv-form input[name='cv-email']").val())) {
		alert("Ошибка: Неверный формат email.");
		return;
	}
	
	if(!validatePhone($("#cv-form input[name='cv-phone']").val())) {
		alert("Ошибка: Неверный формат телефона. Телефон необходимо записать в интернациональном формате.");
		return;
	}

	if($("#cv-form #cv-country").val() == -1) {
		alert("Ошибка: Необходимо выбрать страну.");
		return;
	}
	
	if($("#cv-form #cv-city").val() == -1) {
		alert("Ошибка: Необходимо выбрать город.");
		return;
	}
	
	if(!validateForm("#cv-form")) {
		alert("Ошибка: Данные в форме заполнены неправильно.");
		return;
	}
	
	var photo = document.getElementById('cv-photo');
	if(photo.files.lenght) {
		if(photo.files[0].size > 500000) {
			alert("Ошибка: Изображение не должно превышать размер в 500кб.");
			return;
		}
	}
	
	var formData = new FormData($(this)[0]);
	toggleForm("#cv-form", false);
	
	$.ajax({
		type: "POST",
		url: "/adeon/cv/cv.php",
		data: formData,
		async: true,
		cache: false,
		contentType: false,
		processData: false,
		success: function(data) {
			var obj = JSON.parse(data);
			if(obj.error === undefined) {
				location.reload();
			} 
			else {
				alert("Ошибка: "+obj.error);
				toggleForm("#cv-form", true);
				console.log(obj);
			}
		},
		error: function(error) {
			alert("Ошибка при отправке данных. "+error.status+": "+error.statusText);
			toggleForm("#cv-form", true);
		}
	});
});