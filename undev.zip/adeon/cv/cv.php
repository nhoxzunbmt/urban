<?php
	/* Last modified by Adeon */

	include "../adeon.php";
	include "../../wp-load.php";
	
	$db = "users_cv";
	$userid = get_current_user_id();
	$username = $current_user->user_login;

	if(!$userid) {
		die(json_encode(array("error" => "Unauthorized access"), JSON_UNESCAPED_UNICODE));
	}
	
	if($_SERVER['REQUEST_METHOD'] === 'POST') {
		$wpdb->get_results("SELECT * FROM $db WHERE userid=$userid");
		if(!empty($wpdb->last_error)) {
			die(json_encode(array("error" => $wpdb->last_error), JSON_UNESCAPED_UNICODE));
		}
		
		if(!$_FILES['cv-photo']['error']) {
			$name = $_FILES['cv-photo']['name'];
			if(!check_file_uploaded_length($name)) {
				die(json_encode(array("error" => "Wrong file name"), JSON_UNESCAPED_UNICODE));
			}
				
			if($_FILES['cv-photo']['size'] > 500000) {
				die(json_encode(array("error" => "Wrong file size"), JSON_UNESCAPED_UNICODE));
			}
			
			if (!file_exists("../../cv_data/users/$username")) {
				mkdir("../../cv_data/users/$username", 0777, true);
			}
			
			move_uploaded_file($_FILES['cv-photo']['tmp_name'], "../../cv_data/users/$username/photo.jpg");
		}
	
		$data = array(
			'userid' => $userid,
			'user_name' => $username,
			'name' => $_POST['cv-name'],
			'spec' => $_POST['cv-spec'],
			'info' => $_POST['cv-info'],
			'age' => $_POST['cv-age'],
			'address' => $_POST['cv-address'],
			'email' => $_POST['cv-email'],
			'city' => $_POST['cv-city'],
			'country' => $_POST['cv-country'],
			'phone' => $_POST['cv-phone'],
			'state' => 1,
			'time' => current_time('mysql'),
			'has_photo' => file_exists("../../cv_data/users/$username")
		);
		$data_pattern = array('%d', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%d', '%d', '%s', '%d', '%s', '%d');
		$where = array('userid' => $userid);
		$where_pattern = array('%d');
		
		if($wpdb->num_rows > 0) {
			$result = $wpdb->get_results("SELECT time FROM $db WHERE userid=$userid");
			if(!empty($wpdb->last_error)) {
				die(json_encode(array("error" => $wpdb->last_error), JSON_UNESCAPED_UNICODE));
			}
			
			$cur_date = new DateTime(date("Y-m-d H:i:s"));
			$last_date = new DateTime($result[0]->time);
			$diff = $cur_date->diff($n);
			$hours = $diff->h;
			$hours = $hours + ($diff->days*24);
			
			if($hours < 24) {
				die(json_encode(array("error" => 'You can change your CV only 1 time per 24 hours'), JSON_UNESCAPED_UNICODE));
			}

			$wpdb->update($db, $data, $where, $data_pattern, $where_pattern);
			if(!empty($wpdb->last_error)) {
				die(json_encode(array("error" => $wpdb->last_error), JSON_UNESCAPED_UNICODE));
			}
			
			die(json_encode(array("data" => array("action" => "update")), JSON_UNESCAPED_UNICODE));
		}
		else {
			$wpdb->insert($db, $data, $data_pattern);
			if(!empty($wpdb->last_error)) {
				die(json_encode(array("error" => $wpdb->last_error), JSON_UNESCAPED_UNICODE));
			}
			
			die(json_encode(array("data" => array("action" => "insert")), JSON_UNESCAPED_UNICODE));
		}
	}
	else if($_SERVER['REQUEST_METHOD'] === "GET") {
		$result = $wpdb->get_results("SELECT COUNT(*) AS max FROM $db");
		if(!empty($wpdb->last_error)) {
			die(json_encode(array("error" => $wpdb->last_error), JSON_UNESCAPED_UNICODE));
		}
		
		$max = $result[0]->max;
		
		if(!$max) {
			die(json_encode(array("data" => null), JSON_UNESCAPED_UNICODE));
		}
		
		$result = $wpdb->get_results("SELECT * FROM $db WHERE userid=$userid", ARRAY_A);
		if(!empty($wpdb->last_error)) {
			die(json_encode(array("error" => $wpdb->last_error), JSON_UNESCAPED_UNICODE));
		}
		
		if(!$result) {
			die(json_encode(array("data" => null), JSON_UNESCAPED_UNICODE));
		}
		
		$data = array(
			'userid' => $userid,
			'user_name' => $username,
			'name' => $result[0]['name'],
			'spec' => $result[0]['spec'],
			'info' => $result[0]['info'],
			'age' => $result[0]['age'],
			'address' => $result[0]['address'],
			'email' => $result[0]['email'],
			'city' => $result[0]['city'],
			'country' => $result[0]['country'],
			'phone' => $result[0]['phone'],
			'state' => $result[0]['state'],
			'time' => $result[0]['time'],
			'msg' => $result[0]['msg'],
			'has_photo' => file_exists("../../cv_data/users/$username")
		);
	
		die(json_encode($data, JSON_UNESCAPED_UNICODE));
	}
?>