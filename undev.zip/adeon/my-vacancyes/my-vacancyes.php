<?php
	include "../../wp-load.php";
	$userid = get_current_user_id();
	if(!$userid) {
		die(json_encode(array("error" => "Unauthorized access"), JSON_UNESCAPED_UNICODE));
	}
	
	if($_SERVER['REQUEST_METHOD'] === "GET") {
		$db = "users_vac";
		$result = $wpdb->get_results("SELECT COUNT(*) AS max FROM $db WHERE userid = $userid", ARRAY_A);
		if(!empty($wpdb->last_error)) die(json_encode(array("error" => $wpdb->last_error), JSON_UNESCAPED_UNICODE));
		
		$max = isset($_GET['max']) ? $_GET['max'] : $result[0]['max'];
		$from = isset($_GET['from']) ? $_GET['from'] : 0;
		if($from >= $max) $from = 0;
		
		$result = $wpdb->get_results("SELECT * FROM $db WHERE userid = $userid LIMIT $from, $max", ARRAY_A);
		if(!empty($wpdb->last_error)) die(json_encode(array("error" => $wpdb->last_error), JSON_UNESCAPED_UNICODE));

		if(!$max) {
			die(json_encode(array("data" => null), JSON_UNESCAPED_UNICODE));
		}
		$data = array();

		foreach($result as $vac) {
			$data[] = array(				'id' => $vac['id'],
				'userid' => $userid,
				'username' => $vac["username"],
				'name' => $vac["name"],
				'spec' => $vac["spec"],
				'info' => $vac["info"],
				'act' => $vac["act"],
				'qual' => $vac["qual"],
				'date' => $vac["date"],
				'city' => $vac["city"],
				'country' => $vac["country"],
				'state' => $vac["state"],
				'msg' => $vac["msg"],
				'has_photo' => file_exists("../../vac_data/users/".$vac["username"]."/".$vac['id'].".jpg")
			);
		}
		
		die(json_encode(array("data" => $data), JSON_UNESCAPED_UNICODE));
	}
?>