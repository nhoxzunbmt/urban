<?php
	include "../../wp-load.php";
	$userid = get_current_user_id();
	if(!$userid) {
		die(json_encode(array("error" => "Unauthorized access"), JSON_UNESCAPED_UNICODE));
	}
	
	if($_SERVER['REQUEST_METHOD'] === "GET") {
		$db = "users_cv";
		$result = $wpdb->get_results("SELECT COUNT(*) AS max FROM $db WHERE state = 2", ARRAY_A);
		if(!empty($wpdb->last_error)) die(json_encode(array("error" => $wpdb->last_error), JSON_UNESCAPED_UNICODE));
		
		$max = isset($_GET['max']) ? $_GET['max'] : $result[0]['max'];
		$from = isset($_GET['from']) ? $_GET['from'] : 0;
		if($from >= $max) $from = 0;
		
		$result = $wpdb->get_results("SELECT * FROM $db WHERE state = 2 LIMIT $from, $max", ARRAY_A);
		if(!empty($wpdb->last_error)) die(json_encode(array("error" => $wpdb->last_error), JSON_UNESCAPED_UNICODE));

		if(!$max) {
			die(json_encode(array("data" => null), JSON_UNESCAPED_UNICODE));
		}
		
		$data = array();

		foreach($result as $cv) {
			$data[] = array(
				'user_name' => $cv["user_name"],
				'name' => $cv["name"],
				'spec' => $cv["spec"],
				'info' => $cv["info"],
				'age' => $cv["age"],
				'address' => $cv["address"],
				'email' => $cv["email"],
				'city' => $cv["city"],
				'country' => $cv["country"],
				'phone' => $cv["phone"],
				'state' => $cv["state"],
				'time' => $cv["time"],
				'msg' => $cv["msg"],
				'has_photo' => file_exists("../../cv_data/users/".$cv["user_name"])
			);
		}
		
		die(json_encode(array("data" => $data, "get" => $_GET), JSON_UNESCAPED_UNICODE));
	}
?>